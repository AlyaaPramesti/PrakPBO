/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bidang;

/**
 *
 * @author ROG
 */
public class Persegi implements MenghitungBidang{
    
    double Panjang, Lebar;

    public Persegi(double panjang, double lebar) {
        this.Panjang = panjang;
        this.Lebar = lebar;
    }

    @Override
    public double Keliling() {
        return 2 * (Panjang + Lebar);
    }

    @Override
    public double Luas() {
        return Panjang * Lebar;
    }
   
}

