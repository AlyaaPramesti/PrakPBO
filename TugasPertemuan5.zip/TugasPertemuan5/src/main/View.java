/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;
import ruang.Balok;
import bidang.Persegi;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author ROG
 */
public class View extends JFrame implements ActionListener{
    double Panjang, Lebar, Tinggi;
    
    JTextField flength = new JTextField(6);
    JTextField fwidth = new JTextField(6);
    JTextField fheight = new JTextField(6);
    
    JLabel ltitle = new JLabel ("Cuboid Calculator");
    JLabel llength = new JLabel ("Length");
    JLabel lwidth = new JLabel ("Width");
    JLabel lheight = new JLabel ("Height");
    JLabel lresult = new JLabel ("Result :");
    JLabel lluas = new JLabel (" ");
    JLabel lkeliling = new JLabel (" ");
    JLabel lvolume = new JLabel (" ");
    JLabel llpermukaan = new JLabel (" ");
    JButton count = new JButton ("Count");
    JButton reset = new JButton ("Reset");
    
    public View(){
        setDefaultCloseOperation(3);
        setSize(380, 500);
        ltitle.setHorizontalAlignment(SwingConstants.CENTER);
        lresult.setHorizontalAlignment(SwingConstants.CENTER);
        
        setLayout(null);
        add(ltitle);
        add(llength);
        add(flength);
        add(lwidth);
        add(fwidth);
        add(lheight);
        add(fheight);
        add(lresult);
        add(count);
        add(reset);
        
        ltitle.setBounds(90,20,200,20);
        llength.setBounds(30,100,120,20);
        flength.setBounds(140,100,200,20);
        lwidth.setBounds(30,140,120,20);
        fwidth.setBounds(140,140,200,20);
        lheight.setBounds(30,180,120,20);
        fheight.setBounds(140,180,200,20);
        lresult.setBounds(110,210,120,20);
        count.setBounds(120,400,90,20);
        reset.setBounds(220,400,90,20);
        
        count.addActionListener(this);
        reset.addActionListener(this);
        
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }
    
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == count){
            try{
             Panjang = Double.valueOf(flength.getText());
             Lebar = Double.valueOf(fwidth.getText());
             Tinggi = Double.valueOf(fheight.getText());
             
             Persegi Pp = new Persegi(Panjang, Lebar);
             Balok B = new Balok(Panjang, Lebar, Tinggi);
             
             lluas = new JLabel("Square Area  : " + Pp.Luas());
             lkeliling = new JLabel("Square Circumference  : " + Pp.Keliling());
             lvolume = new JLabel("Cuboid Volume  : " + B.Volume());
             llpermukaan = new JLabel("Cuboid Surface Area  : " + B.LPermukaan());
            
             add(lluas);
             add(lkeliling);
             add(lvolume);
             add(llpermukaan);
            
             lluas.setBounds(30,240,200,20);
             lkeliling.setBounds(30,280,200,20);
             lvolume.setBounds(30,320,200,20);
             llpermukaan.setBounds(30,360,200,20);
             
             setVisible(true);
             
            }catch(NumberFormatException error){
                 String message = "Input Salah. Mohon Masukkan Angka!";
                JOptionPane.showMessageDialog(new JFrame(), message, "Message", JOptionPane.INFORMATION_MESSAGE);
            }  
        }
     

        if(e.getSource() == reset){
            flength.setText("");
            fwidth.setText("");
            fheight.setText("");
            lluas.setText("");
            lkeliling.setText("");
            lvolume.setText("");
            llpermukaan.setText("");
        }        
    }  
}

